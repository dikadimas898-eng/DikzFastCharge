package com.dikz.fastcharge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings

class PowerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("dikz_fastcharge", Context.MODE_PRIVATE)
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                if (prefs.getBoolean("enabled", false) && Settings.canDrawOverlays(context)) {
                    val service = Intent(context, ChargeOverlayService::class.java)
                        .setAction(ChargeOverlayService.ACTION_CHARGER_CONNECTED)
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startForegroundService(service)
                        } else {
                            context.startService(service)
                        }
                    } catch (_: Exception) {
                        // Android may restrict background starts on some devices.
                    }
                }
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                context.startService(Intent(context, ChargeOverlayService::class.java)
                    .setAction(ChargeOverlayService.ACTION_HIDE))
            }
            Intent.ACTION_BOOT_COMPLETED -> {
                // User must open the app once and enable the feature; the receiver does not
                // start an always-on service automatically at boot.
            }
        }
    }
}
