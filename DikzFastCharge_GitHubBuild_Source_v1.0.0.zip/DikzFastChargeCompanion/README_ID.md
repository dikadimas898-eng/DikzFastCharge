# Dikz FastCharge Companion — sumber awal

Proyek Android Studio untuk pendamping plugin AX Manager. Tujuannya adalah menampilkan overlay ketika Android memberi broadcast charger tersambung.

## Yang ada pada prototipe ini
- UI pengaturan sederhana.
- Izin `Tampil di atas aplikasi lain`.
- Overlay charging dengan persentase baterai Android.
- Overlay hilang otomatis setelah 4 detik; ketuk overlay untuk menutup.
- Tombol uji animasi.

## Batasan penting
- Ini **source project**, bukan APK yang sudah dikompilasi atau diuji di Luna V6.
- Android/OEM dapat membatasi receiver atau start service dari background; perilaku otomatis perlu diuji di perangkat.
- Prototipe ini belum membuat animasi lingkaran energi yang kompleks, belum menampilkan suhu/arus/tegangan, dan tidak meningkatkan daya pengisian.
- Pengguna perlu membuka aplikasi, memberi izin overlay, lalu mengaktifkan otomatis.
- Jangan gabungkan dengan plugin AX Manager sampai format modul dan kebutuhan integrasi diverifikasi.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `DikzFastChargeCompanion` di Android Studio.
3. Tunggu Gradle sync.
4. Build APK debug dan pasang di perangkat uji.
5. Beri izin overlay, tekan **Aktifkan layanan**, lalu uji colok-cabut charger.

Perlu Android Studio dengan Android SDK 35 dan Gradle/AGP yang kompatibel. Source ini adalah titik awal untuk pengujian, bukan klaim kompatibilitas terjamin.


## Build APK via GitHub Actions (from phone)

1. Create a GitHub repository and upload the **contents** of this project folder (not the outer ZIP).
2. Make sure `.github/workflows/build.yml` is included. On GitHub mobile web, hidden `.github` paths can be awkward to upload; if needed create the workflow file in GitHub's web editor at `.github/workflows/build.yml`.
3. Open the repository → **Actions** → **Build Dikz FastCharge APK** → **Run workflow**.
4. Wait for the workflow to finish. Open the completed run and download the artifact named `DikzFastCharge-debug-apk`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow builds the debug APK; it does not make this source production-ready or prove the background charger event works on every Android device. The first build may fail if Android/Gradle dependencies or source issues need adjustments.

