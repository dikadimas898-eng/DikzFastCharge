package com.dikz.fastcharge

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.drawable.GradientDrawable

class ChargeOverlayService : Service() {
    companion object {
        const val ACTION_CHARGER_CONNECTED = "com.dikz.fastcharge.CHARGER_CONNECTED"
        const val ACTION_SHOW_TEST = "com.dikz.fastcharge.SHOW_TEST"
        const val ACTION_HIDE = "com.dikz.fastcharge.HIDE"
    }

    private var windowManager: WindowManager? = null
    private var overlay: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private val hideTask = Runnable { hideOverlay() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> hideOverlay()
            ACTION_CHARGER_CONNECTED, ACTION_SHOW_TEST -> {
                if (Settings.canDrawOverlays(this)) showOverlay()
            }
        }
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        hideOverlay()
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { hideOverlay() }
        }
        val panel = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12, 18, 36), Color.rgb(36, 18, 62))
            ).apply {
                cornerRadius = 36f
                setStroke(3, Color.rgb(57, 210, 255))
            }
            elevation = 20f
        }
        val headline = TextView(this).apply {
            text = "⚡  CHARGING"
            textSize = 15f
            setTextColor(Color.rgb(83, 220, 255))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val batteryText = TextView(this).apply {
            text = if (percent >= 0) "$percent%" else "Battery"
            textSize = 44f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val hint = TextView(this).apply {
            text = "DIKZ FASTCHARGE  •  ketuk untuk menutup"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        panel.addView(headline, FrameLayout.LayoutParams(-1, 48).apply { gravity = Gravity.TOP })
        panel.addView(batteryText, FrameLayout.LayoutParams(-1, 90).apply { gravity = Gravity.CENTER })
        panel.addView(hint, FrameLayout.LayoutParams(-1, 36).apply { gravity = Gravity.BOTTOM })
        root.addView(panel, FrameLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.86f).toInt(), 174
        ).apply { gravity = Gravity.CENTER })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager?.addView(root, params)
            overlay = root
            handler.removeCallbacks(hideTask)
            handler.postDelayed(hideTask, 4000)
        } catch (_: Exception) {
            hideOverlay()
        }
    }

    private fun hideOverlay() {
        handler.removeCallbacks(hideTask)
        try {
            overlay?.let { windowManager?.removeView(it) }
        } catch (_: Exception) { }
        overlay = null
        stopSelf()
    }

    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
