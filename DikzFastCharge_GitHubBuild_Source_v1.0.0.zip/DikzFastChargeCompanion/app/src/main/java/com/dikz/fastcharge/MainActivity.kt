package com.dikz.fastcharge

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dikz_fastcharge", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(10, 14, 24))
        }
        val title = TextView(this).apply {
            text = "DIKZ FASTCHARGE"
            textSize = 26f
            setTextColor(Color.rgb(83, 220, 255))
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Animasi neon otomatis saat charger tersambung"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }
        val status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val grant = Button(this).apply {
            text = "Izinkan tampil di atas aplikasi lain"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val enable = Button(this).apply {
            text = "Aktifkan layanan"
            setOnClickListener {
                prefs.edit().putBoolean("enabled", true).apply()
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, ChargeOverlayService::class.java)
                        .setAction(ChargeOverlayService.ACTION_SHOW_TEST))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
                refreshStatus(status)
            }
        }
        val preview = Button(this).apply {
            text = "Coba animasi sekarang"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, ChargeOverlayService::class.java)
                        .setAction(ChargeOverlayService.ACTION_SHOW_TEST))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        val disable = Button(this).apply {
            text = "Nonaktifkan otomatis"
            setOnClickListener {
                prefs.edit().putBoolean("enabled", false).apply()
                refreshStatus(status)
            }
        }
        listOf(title, desc, status, grant, enable, preview, disable).forEach {
            root.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 })
        }
        setContentView(root)
        refreshStatus(status)
    }

    override fun onResume() {
        super.onResume()
        findStatusAndRefresh()
    }

    private fun findStatusAndRefresh() {
        val root = window.decorView.findViewWithTag<TextView>("status")
        if (root != null) refreshStatus(root)
    }

    private fun refreshStatus(view: TextView) {
        val enabled = prefs.getBoolean("enabled", false)
        val overlay = Settings.canDrawOverlays(this)
        view.tag = "status"
        view.text = "Otomatis: ${if (enabled) "AKTIF" else "NONAKTIF"}\\nIzin overlay: ${if (overlay) "DIIZINKAN" else "BELUM DIIZINKAN"}\\n\\nCatatan: beberapa versi Android membatasi layanan saat berjalan di latar belakang."
    }
}
